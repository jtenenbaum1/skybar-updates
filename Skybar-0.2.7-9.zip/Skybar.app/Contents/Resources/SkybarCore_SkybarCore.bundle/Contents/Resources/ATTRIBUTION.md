Tomorrow.io Weather Code Icons
https://github.com/Tomorrow-IO-API/tomorrow-weather-codes
Source revision: 51b9588fa598d7a8fcf26798854e0d74708abcc4

V1 color SVG artwork was rasterized to 144px PNG; selected V2 large 2x PNG
artwork is bundled unchanged. Both sets are bundled with Skybar under Creative
Commons Attribution 4.0. Files have been renamed to stable resource names. The repository
credits Elad Rahmin and Vera Mordehayev as the designers. See LICENSE.md for
the license text and the in-app "Powered by Tomorrow.io" credit.
